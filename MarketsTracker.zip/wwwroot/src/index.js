﻿import App from "./App.js"
App.init();
